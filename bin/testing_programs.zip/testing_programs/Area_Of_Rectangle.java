package testing_programs;

import java.util.Scanner;

public class Area_Of_Rectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter any two numbers");
		int l=sc.nextInt();
		int b=sc.nextInt();
		System.out.println("area of square is = "+l*b);

	}

}
