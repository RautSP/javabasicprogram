package testing_programs;

public class Result {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
float  f=7.7f;
System.out.println((int)f);
	}

}
